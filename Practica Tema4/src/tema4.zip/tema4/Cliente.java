package tema4;

import java.util.Date;

public class Cliente {
	private String nombre;
	private String apellidos;
	private Date fechaDeAlta;
	private String telefono;
	private String direccion;
	private String historial;

	private static final String Patron = "^[6789][0-9]{8}$";

	public Cliente() {
		this.nombre = "";
		this.apellidos = "";
		this.telefono = "";
		this.direccion = "";
		this.historial = "";
		this.fechaDeAlta = new Date();
	}


	public Cliente(String nombre, String apellidos, String telefono, String direccion, String historial,
			Date fechaDeAlta) {
		this.nombre = nombre.toLowerCase();
		this.apellidos = apellidos.toUpperCase();
		if (telefono.matches(Patron)) {
			this.telefono = telefono;
		} else {
			System.out.println("Formato del numero invalido");

		}
		if (direccion != null && !direccion.isEmpty()) {
			this.direccion = direccion;
		} else {
			System.out.println("No puede estar vacio");

		}
		this.historial = historial;
		this.fechaDeAlta = new Date();
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public Date getFechaDeAlta() {
		return fechaDeAlta;
	}

	public void setFechaDeAlta(Date fechaDeAlta) {
		this.fechaDeAlta = fechaDeAlta;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getHistorial() {
		return historial;
	}

	public void setHistorial(String historial) {
		this.historial = historial;
	}
}
